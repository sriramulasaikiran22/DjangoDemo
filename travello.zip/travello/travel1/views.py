from django.shortcuts import render
from .models import Destination

# Create your views here.

def index(request):
    # dest1 = Destination()
    # dest1.name = 'Kasiralla'
    # dest1.description = 'A place of Memories'
    # dest1.price = 2
    # dest1.image = 'destination_4.jpg'
    # dest1.offer = True

    # dest2 = Destination()
    # dest2.name = 'Perumallapenta'
    # dest2.description = 'A place of Birth'
    # dest2.price = 4
    # dest2.image = 'destination_5.jpg'
    # dest2.offer = False

    # dest3 = Destination()
    # dest3.name = 'Challapalem'
    # dest3.description = 'A place of Affections'
    # dest3.price = 10
    # dest3.image = 'destination_6.jpg'
    # dest3.offer = False

    # dests = [dest1, dest2, dest3]
    dests = Destination.objects.all()

    return render(request, 'index.html', {'dests':dests})

