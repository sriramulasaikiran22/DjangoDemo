from django.shortcuts import render, redirect
from django.contrib.auth.models import User, auth
from django.contrib import messages

# Create your views here.

def signup(request):

    if request.method == "POST":
        first_name = request.POST['firstname']
        last_name = request.POST['lastname']
        email = request.POST['emailid']
        password1 = request.POST['psw']
        password2 = request.POST['cpsw']
        user_name = first_name + " " + last_name

        if password1 == password2:
            if User.objects.filter(email=email).exists():
                messages.error(request, 'email already exists')
                return redirect('signup')
            else:  
                user = User.objects.create_user(username=user_name, email=email, password=password1, first_name=first_name, last_name=last_name)
                user.save()
                messages.info(request, 'user created.')
                return redirect('/')
        else:
            messages.error(request, 'password mismatch')
            return redirect('signup')
                
        
    else:
        return render(request, 'signup.html')
    

def login(request):
    if request.method == "POST":
        username = request.POST['username']
        password =request.POST['psw']
        user = auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request, user)
            return redirect('/')
        else:
            messages.error(request, 'Credentials Not Found')
            return redirect('login')
        
    else:
        return render(request, 'login.html')
    
def logout(request):
    auth.logout(request)
    return redirect('/')
